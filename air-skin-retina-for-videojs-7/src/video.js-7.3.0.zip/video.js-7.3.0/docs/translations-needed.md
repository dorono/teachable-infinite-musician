# Translations needed

The currently available translations are in the lang dir. This table shows the completeness of those translations. Anything not listed does not exist yet, so go ahead and create it by copying `en.json`.

If you add or update a translation run `grunt check-translations` to update the list and include this modified doc in the pull request.

## Progress Bar Translations

The progress bar has a translation with a few token replacements.
They key is `progress bar timing: currentTime={1} duration={2}` and the default English value is `{1} of {2}`.
This default value is hardcoded as a default to the localize method in the SeekBar component.

## Status of translations

<!-- START langtable -->
| Language file           | Missing translations                                                                |
| ----------------------- | ----------------------------------------------------------------------------------- |
| ar.json (missing 51)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Close Modal Dialog                                                                  |
|                         | , opens descriptions settings dialog                                                |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| ba.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| bg.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| ca.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| cs.json (Complete)      |                                                                                     |
| da.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| de.json (missing 1)     | {1} is loading.                                                                     |
| el.json (missing 45)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| es.json (missing 58)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| fa.json (missing 1)     | {1} is loading.                                                                     |
| fi.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| fr.json (missing 1)     | {1} is loading.                                                                     |
| gl.json (missing 58)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| he.json (missing 1)     | {1} is loading.                                                                     |
| hr.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| hu.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| it.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| ja.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| ko.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| nb.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| nl.json (missing 1)     | {1} is loading.                                                                     |
| nn.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| pl.json (missing 51)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Close Modal Dialog                                                                  |
|                         | , opens descriptions settings dialog                                                |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| pt-BR.json (Complete)   |                                                                                     |
| pt-PT.json (missing 44) | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| ru.json (missing 1)     | {1} is loading.                                                                     |
| sk.json (Complete)      |                                                                                     |
| sr.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| sv.json (missing 59)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Descriptions                                                                        |
|                         | descriptions off                                                                    |
|                         | Audio Track                                                                         |
|                         | Volume Level                                                                        |
|                         | The media is encrypted and we do not have the keys to decrypt it.                   |
|                         | Play Video                                                                          |
|                         | Close                                                                               |
|                         | Close Modal Dialog                                                                  |
|                         | Modal Window                                                                        |
|                         | This is a modal window                                                              |
|                         | This modal can be closed by pressing the Escape key or activating the close button. |
|                         | , opens captions settings dialog                                                    |
|                         | , opens subtitles settings dialog                                                   |
|                         | , opens descriptions settings dialog                                                |
|                         | , selected                                                                          |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| tr.json (missing 9)     | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| uk.json (missing 45)    | Audio Player                                                                        |
|                         | Video Player                                                                        |
|                         | Replay                                                                              |
|                         | Progress Bar                                                                        |
|                         | progress bar timing: currentTime={1} duration={2}                                   |
|                         | Volume Level                                                                        |
|                         | captions settings                                                                   |
|                         | subtitles settings                                                                  |
|                         | descriptions settings                                                               |
|                         | Text                                                                                |
|                         | White                                                                               |
|                         | Black                                                                               |
|                         | Red                                                                                 |
|                         | Green                                                                               |
|                         | Blue                                                                                |
|                         | Yellow                                                                              |
|                         | Magenta                                                                             |
|                         | Cyan                                                                                |
|                         | Background                                                                          |
|                         | Window                                                                              |
|                         | Transparent                                                                         |
|                         | Semi-Transparent                                                                    |
|                         | Opaque                                                                              |
|                         | Font Size                                                                           |
|                         | Text Edge Style                                                                     |
|                         | None                                                                                |
|                         | Raised                                                                              |
|                         | Depressed                                                                           |
|                         | Uniform                                                                             |
|                         | Dropshadow                                                                          |
|                         | Font Family                                                                         |
|                         | Proportional Sans-Serif                                                             |
|                         | Monospace Sans-Serif                                                                |
|                         | Proportional Serif                                                                  |
|                         | Monospace Serif                                                                     |
|                         | Casual                                                                              |
|                         | Script                                                                              |
|                         | Small Caps                                                                          |
|                         | Reset                                                                               |
|                         | restore all settings to the default values                                          |
|                         | Done                                                                                |
|                         | Caption Settings Dialog                                                             |
|                         | Beginning of dialog window. Escape will cancel and close the window.                |
|                         | End of dialog window.                                                               |
|                         | {1} is loading.                                                                     |
| vi.json (missing 1)     | {1} is loading.                                                                     |
| zh-CN.json (missing 2)  | progress bar timing: currentTime={1} duration={2}                                   |
|                         | {1} is loading.                                                                     |
| zh-TW.json (missing 2)  | progress bar timing: currentTime={1} duration={2}                                   |
|                         | {1} is loading.                                                                     |
<!-- END langtable -->
